package com.Board.BoardAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
